const deliveryForm = document.getElementById('deliveryForm');
const deliveryTable = document.getElementById('deliveryTable').getElementsByTagName('tbody')[0];
const reportStatus = document.getElementById('reportStatus');
const generateReport = document.getElementById('generateReport');
const reportResults = document.getElementById('reportResults');

const apiUrl = 'http://localhost:3000/deliveries';
let editMode = false;
let editId = null;

// Fetch and display deliveries
function fetchDeliveries() {
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            deliveryTable.innerHTML = '';
            data.forEach(delivery => {
                const row = deliveryTable.insertRow();
                row.innerHTML = `
                    <td>${delivery.recipientName}</td>
                    <td>${delivery.address}</td>
                    <td>${new Date(delivery.deliveryDate).toLocaleDateString()}</td>
                    <td>${delivery.status}</td>
                    <td class="actions">
                        <button onclick="editDelivery('${delivery._id}')">Edit</button>
                        <button onclick="deleteDelivery('${delivery._id}')">Delete</button>
                    </td>
                `;
            });
        });
}

// Add or update delivery
deliveryForm.addEventListener('submit', function (e) {
    e.preventDefault();

    const deliveryData = {
        recipientName: document.getElementById('recipientName').value,
        address: document.getElementById('address').value,
        deliveryDate: document.getElementById('deliveryDate').value,
        status: document.getElementById('status').value
    };

    if (editMode && editId) {
        // Update existing delivery
        fetch(`${apiUrl}/${editId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(deliveryData)
        })
        .then(response => response.json())
        .then(() => {
            fetchDeliveries();
            deliveryForm.reset();
            editMode = false;
            editId = null;
        });
    } else {
        // Add new delivery
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(deliveryData)
        })
        .then(response => response.json())
        .then(() => {
            fetchDeliveries();
            deliveryForm.reset();
        });
    }
});

// Edit delivery
function editDelivery(id) {
    fetch(`${apiUrl}/${id}`)
        .then(response => response.json())
        .then(delivery => {
            document.getElementById('recipientName').value = delivery.recipientName;
            document.getElementById('address').value = delivery.address;
            document.getElementById('deliveryDate').value = delivery.deliveryDate.split('T')[0];
            document.getElementById('status').value = delivery.status;

            editMode = true;
            editId = id;
        });
}

// Delete delivery
function deleteDelivery(id) {
    fetch(`${apiUrl}/${id}`, {
        method: 'DELETE'
    })
    .then(() => fetchDeliveries());
}

// Generate report and download as PDF
generateReport.addEventListener('click', function () {
    const status = reportStatus.value;
    fetch(`${apiUrl}/report/${status}`)
        .then(response => response.json())
        .then(data => {
            reportResults.innerHTML = `<h3>Deliveries with status: ${status}</h3>`;
            const doc = new jspdf.jsPDF();
            let content = `Report for deliveries with status: ${status}\n\n`;
            if (data.length > 0) {
                data.forEach(delivery => {
                    const deliveryInfo = `${delivery.recipientName} - ${delivery.address} - ${new Date(delivery.deliveryDate).toLocaleDateString()}\n`;
                    reportResults.innerHTML += `<p>${deliveryInfo}</p>`;
                    content += deliveryInfo;
                });
            } else {
                content += 'No deliveries found.\n';
                reportResults.innerHTML += `<p>No deliveries found.</p>`;
            }
            doc.text(content, 10, 10);
            doc.save(`Delivery_Report_${status}.pdf`);
        });
});

// Initial fetch
fetchDeliveries();
