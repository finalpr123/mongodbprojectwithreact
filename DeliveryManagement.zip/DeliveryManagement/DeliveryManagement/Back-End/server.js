const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

mongoose.connect('mongodb+srv://pasanmahee:fVgPys0uknMCuT8S@cluster0.zwasfmo.mongodb.net/deliverymanagementdb?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const DeliverySchema = new mongoose.Schema({
    recipientName: String,
    address: String,
    deliveryDate: Date,
    status: String
});

const Delivery = mongoose.model('Delivery', DeliverySchema);

// Create
app.post('/deliveries', async (req, res) => {
    try {
        const delivery = new Delivery(req.body);
        await delivery.save();
        res.status(201).send(delivery);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Read All
app.get('/deliveries', async (req, res) => {
    try {
        const deliveries = await Delivery.find();
        res.status(200).send(deliveries);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Read One
app.get('/deliveries/:id', async (req, res) => {
    try {
        const delivery = await Delivery.findById(req.params.id);
        if (!delivery) {
            return res.status(404).send('Delivery not found');
        }
        res.status(200).send(delivery);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Update
app.put('/deliveries/:id', async (req, res) => {
    try {
        const delivery = await Delivery.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!delivery) {
            return res.status(404).send('Delivery not found');
        }
        res.status(200).send(delivery);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Delete
app.delete('/deliveries/:id', async (req, res) => {
    try {
        const delivery = await Delivery.findByIdAndDelete(req.params.id);
        if (!delivery) {
            return res.status(404).send('Delivery not found');
        }
        res.status(200).send(delivery);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Report Generation (Example: Get all deliveries with a specific status)
app.get('/deliveries/report/:status', async (req, res) => {
    try {
        const deliveries = await Delivery.find({ status: req.params.status });
        res.status(200).send(deliveries);
    } catch (error) {
        res.status(500).send(error);
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

